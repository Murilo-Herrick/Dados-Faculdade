/**
 * 
 */
/**
 * 
 */
module projetoIntegrador {
	requires java.desktop;
	requires com.fazecast.jSerialComm;
}